from selenium.webdriver.common.by import By

# main page locators
USER_AGREE = (By.ID, 'onetrust-accept-btn-handler')
QUIZ_BUTTON = (By.XPATH, '//a[@class="button button--clickable button--cta"]')
MAJA_BUTTON = (By.ID, 'hero3')
